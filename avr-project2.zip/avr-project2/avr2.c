#include <mega16.h>
#include <alcd.h>
#include <delay.h>
#include <stdio.h>

#define FAN_PIN 7 // Pin connected to the fan and lamp (PD7)

// Initialize USART for serial communication
void init_usart(void) {
    UCSRB = (1 << RXEN) | (1 << TXEN);  // Enable USART receiver and transmitter
    UCSRC = (1 << URSEL) | (1 << UCSZ1) | (1 << UCSZ0);  // Set frame format: 8 data bits, 1 stop bit
    UBRRH = 0;
    UBRRL = 51;  // Set baud rate to 9600 (assuming 8 MHz clock)
}

// Receive a single character via USART
char receive_message(void) {
    while (!(UCSRA & (1 << RXC)));  // Wait until data is received
    return UDR;  // Return the received character
}

// Configure pins for fan and lamp, and LCD (Port B for LCD)
void init_pins(void) {
    DDRD |= (1 << FAN_PIN);  // Configure PD7 as an output for fan and lamp
    DDRB = 0xFF;            // Configure all Port B pins as outputs (for LCD)
    PORTB = 0x00;           // Initialize Port B outputs to 0
}

// Initialize ADC for LM35 temperature sensor
void init_adc(void) {
    ADMUX = (1 << REFS0);  // Use AVCC (5V) as reference voltage
    ADCSRA = (1 << ADEN) | (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0); 
    // Enable ADC and set prescaler to 128 for accurate conversion
}

// Read ADC value from channel 0 (connected to LM35)
unsigned int read_temperature(void) {
    ADMUX = (ADMUX & 0xF0) | (0x00);  // Select ADC channel 0
    ADCSRA |= (1 << ADSC);            // Start ADC conversion
    while (ADCSRA & (1 << ADSC));     // Wait until conversion is complete
    return (ADCL | (ADCH << 8));      // Combine low and high bytes of ADC result
}

// Send a message string via USART
void send_message(const char *message) {
    while (*message) {
        while (!(UCSRA & (1 << UDRE)));  // Wait until UDR is ready for transmission
        UDR = *message++;  // Send the next character
    }
}

void main(void) {
    unsigned int adc_value;   // Variable to store ADC value
    char buffer[16];          // Buffer for storing string data
    char received;            // Variable to store received character
    float temp_in_celsius;    // Variable to store temperature in Celsius

    lcd_init(8);       // Initialize the LCD with 8-bit mode
    init_pins();       // Configure pins
    init_adc();        // Initialize ADC
    init_usart();      // Initialize USART for serial communication

    while (1) {
        adc_value = read_temperature();   // Read temperature from LM35 sensor
        temp_in_celsius = (adc_value * 5.0 / 1024.0) * 100.0;  
        // Convert ADC value to temperature in Celsius:
        // - ADC range is 0-1023 for 10-bit resolution
        // - Multiply by 5.0 to scale to voltage (assuming 5V reference)
        // - LM35 outputs 10mV per degree Celsius, so multiply by 100

        lcd_clear();  // Clear the LCD screen
        lcd_gotoxy(0, 0);  // Set cursor to the first row, first column
        lcd_puts(buffer);  // Display temperature on the LCD

        if (temp_in_celsius > 30.0) {  
            PORTD |= (1 << FAN_PIN);  // Turn on the fan and lamp
            lcd_gotoxy(0, 1);         // Set cursor to the second row
            lcd_puts("Temp>30C DANGER!");  // Display warning message on LCD
            send_message("Temp > 30C DANGER!");  // Send warning message via USART
        } else {
            PORTD &= ~(1 << FAN_PIN);  // Turn off the fan and lamp
            lcd_gotoxy(0, 1);          // Set cursor to the second row
            lcd_puts("                ");  // Clear the second row
        }

        // Check if data is available to read from USART
        if (UCSRA & (1 << RXC)) {
            received = receive_message();  // Read received character
            lcd_gotoxy(0, 1);              // Display it on the second row of the LCD
            lcd_putchar(received);
        }

        delay_ms(1000);  // Delay for 1 second
    }
}


